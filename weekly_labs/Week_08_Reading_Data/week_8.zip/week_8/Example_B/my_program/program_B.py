print('hello')

with open('../student_marks.csv') as f:
    f.read()