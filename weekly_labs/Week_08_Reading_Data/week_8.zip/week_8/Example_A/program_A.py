print('hello')

with open('student_marks.csv') as file:
    file.read()