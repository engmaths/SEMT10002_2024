cities = ['London', 'Bristol', 'Manchester', 'Reading', 'Liverpool', 'Brighton']

populations = [8982000, 467000, 553000, 174224, 496000, 290000]








