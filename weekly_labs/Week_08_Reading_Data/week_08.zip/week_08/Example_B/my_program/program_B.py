with open('../student_marks.csv') as f:
    print(f.read())